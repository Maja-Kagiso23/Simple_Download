package csc2b.client;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.StringTokenizer;

import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class ZEDEMClientPane extends GridPane {
    private Socket clientConnecting;
    private OutputStream os;
    private InputStream is;
    private BufferedReader bReader;
    private PrintWriter pWriter;
    private DataOutputStream dos;
    private DataInputStream dis;
    private String[] listData;
    private String Name, Password;
    
    // GUI elements
    private Button btnLogin, btnPULL;
    private TextField txtIDToRetrieve, txtName, txtPassword;
    private Label lblID;
    private Button btnGetPDFs, btnLogOff;
    private TextArea listArea;
    private Label lblList;


    public ZEDEMClientPane(Stage stage) {
        setupUI();
        establishConn();
        btnPULL.setOnAction((e) -> getPLAYLIST());
        btnGetPDFs.setOnAction((e) -> getMusic());
        btnLogOff.setOnAction((e) -> logOff());
        
        btnLogin.setOnAction((e) -> {
        	Name = txtName.getText(); Password = txtPassword.getText(); 
        	login(Name, Password);   
        });
    }

    private void setupUI() {
        setHgap(10);
        setVgap(10);
        setAlignment(Pos.CENTER);

        // Name and Password fields
        txtName = new TextField();
        txtPassword = new PasswordField();

        // Buttons
        btnPULL = new Button("PLAYLIST");
        txtIDToRetrieve = new TextField();
        lblID = new Label("File ID to retrieve:");
        btnGetPDFs = new Button("DOWNLOAD");
        btnLogOff = new Button("Log Off");
        listArea = new TextArea();
        lblList = new Label("File List:");
        btnLogin = new Button("Login");

        add(new Label("Name:"), 0, 0);
        add(txtName, 1, 0);
        add(new Label("Password:"), 0, 1);
        add(txtPassword, 1, 1);
        add(btnLogin, 1, 2);
        
        add(btnPULL, 1, 3);
        add(lblID, 0, 4);
        add(txtIDToRetrieve, 1, 4);
        add(btnGetPDFs, 2, 4);
        add(btnLogOff, 3, 4);
        add(lblList, 0, 5);
        add(listArea, 0, 6, 4, 1);
    }

    private void login(String enteredName, String enteredPassword) {
        sendCommand(enteredName + " " + enteredPassword);
    }

    private void establishConn() {
        try {
            clientConnecting = new Socket("localhost", 2021);
            os = clientConnecting.getOutputStream();
            is = clientConnecting.getInputStream();
            bReader = new BufferedReader(new InputStreamReader(is));
            pWriter = new PrintWriter(os);
            dis = new DataInputStream(is);
            dos = new DataOutputStream(os);
        } catch (IOException ex) {
            System.err.println("Could not connect to server");
        }
    }

    private void getPLAYLIST() {
        sendCommand("PLAYLIST ");
        String response;
        try {
            response = bReader.readLine();
            System.out.println(response);
            
            // Split the response into an array of music data
            listData = response.split("#");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void sendCommand(String command) {
        pWriter.println(command);
        pWriter.flush();
    }

    private void getMusic() {
        String fileToGetName = "";
        int idToRetrieve = Integer.parseInt(txtIDToRetrieve.getText());
        sendCommand("ZEDEMGET " + idToRetrieve);
        String response = "";

        try {
            response = bReader.readLine();
            int fileSize = Integer.parseInt(response);

            for (String item : listData) {
                StringTokenizer tokenizer = new StringTokenizer(item);
                String id = tokenizer.nextToken();
                String name = tokenizer.nextToken();
                if (id.equals(txtIDToRetrieve.getText())) {
                    fileToGetName = name;
                }
            }

            File fileDownloaded = new File("data/client/" + fileToGetName);
            try (FileOutputStream fos = new FileOutputStream(fileDownloaded)) {
                byte[] buffer = new byte[1024];
                int n;
                int totalBytes = 0;

                while (totalBytes != fileSize) {
                    n = dis.read(buffer, 0, buffer.length);
                    fos.write(buffer, 0, n);
                    fos.flush();
                    totalBytes += n;
                }

                System.out.println("File saved on the client side");
            }
        } catch (IOException e1) {
            e1.printStackTrace();
        }
    }

    private void logOff() {
        sendCommand("ZEDEMBYE ");
        closeStreams();
        System.out.println("User logged out!");
    }

    private void closeStreams() {
        try {
            if (clientConnecting != null)
                clientConnecting.close();
            if (is != null)
                is.close();
            if (os != null)
                os.close();
            if (dos != null)
                dos.close();
            if (dis != null)
                dis.close();
            if (bReader != null)
                bReader.close();
            if (pWriter != null)
                pWriter.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    

}
