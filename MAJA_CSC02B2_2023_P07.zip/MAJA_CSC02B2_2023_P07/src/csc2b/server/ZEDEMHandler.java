package csc2b.server;

import java.io.*;
import java.net.Socket;
import java.util.Scanner;
import java.util.StringTokenizer;

public class ZEDEMHandler implements Runnable {

    private InputStream is;
    private OutputStream os;
    private DataOutputStream dos;
    private DataInputStream dis;
    private BufferedReader bReader;
    private PrintWriter pWriter;

    private boolean isAuthenticated;
    private boolean isServerRunning;
    private Socket serverConnection;
    private String username;
    private int fileSize = 2048;

    public ZEDEMHandler(Socket connection) {
        this.serverConnection = connection;
        initialiseStreams();
    }

    private void initialiseStreams() {
        try {
            is = serverConnection.getInputStream();
            os = serverConnection.getOutputStream();
            bReader = new BufferedReader(new InputStreamReader(is));
            pWriter = new PrintWriter(os, true);
            dos = new DataOutputStream(os);
            dis = new DataInputStream(is);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private boolean authenticate(String inputUsername, String inputPassword) {
        try {
            File userListFile = new File("data/server/users.txt");
            Scanner scanner = new Scanner(userListFile);

            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                StringTokenizer tokenizer = new StringTokenizer(line);
                String storedUsername = tokenizer.nextToken();
                String storedPassword = tokenizer.nextToken();

                if (storedUsername.equals(inputUsername) && storedPassword.equals(inputPassword)) {
                    this.username = inputUsername;
                    return true;
                }
            }
            scanner.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private void login() {
        try {
            while (!isAuthenticated) {
                String message = bReader.readLine();
                System.out.println("Message: " + message);
                StringTokenizer st = new StringTokenizer(message);
                String command = st.nextToken().toUpperCase();
                switch (command) {
                    case "AUTH": {
                        String inputUsername = st.nextToken();
                        String inputPassword = st.nextToken();
                        if (authenticate(inputUsername, inputPassword)) {
                            pWriter.println("AUTH_SUCCESS");
                            pWriter.flush();
                            isAuthenticated = true;
                        } else {
                            pWriter.println("AUTH_FAILURE");
                            pWriter.flush();
                        }
                        break;
                    }
                    default: {
                        pWriter.println("AUTH_REQUIRED");
                        pWriter.flush();
                        break;
                    }
                }
            }
        } catch (IOException ex) {
            System.err.println("Could not log in");
        }
    }

    private String getFileIdFromList(String fileID) {
        String fileName = "";
        try {
            File fileList = new File("data/server/List.txt");
            Scanner sc = new Scanner(fileList);
            while (sc.hasNextLine()) {
                String line = sc.nextLine();
                StringTokenizer tokenizer = new StringTokenizer(line);
                String id = tokenizer.nextToken();
                String fName = tokenizer.nextToken();

                if (id.equals(fileID)) {
                    fileName = fName;
                    break;
                }
            }
            sc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return fileName;
    }

    private void getMusic(String fileID) {
        try {
            String fileName = getFileIdFromList(fileID);
            File fileMusic = new File("data/server/" + fileName);
            if (fileMusic.exists()) {
                pWriter.println(fileMusic.length());
                pWriter.flush();
                FileInputStream fis = new FileInputStream(fileMusic);

                byte[] buffer = new byte[fileSize];
                int n;

                while ((n = fis.read(buffer)) > 0) {
                    dos.write(buffer, 0, n);
                    dos.flush();
                }
                fis.close();
                System.out.println("The file was sent to the client successfully");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void logOff() {
        isAuthenticated = false;
        closeStreams();
    }

    private void closeStreams() {
        try {
            if (serverConnection != null) {
                serverConnection.close();
            }
            if (is != null) {
                is.close();
            }
            if (os != null) {
                os.close();
            }
            if (dis != null) {
                dis.close();
            }
            if (dos != null) {
                dos.close();
            }
            if (pWriter != null) {
                pWriter.close();
            }
            if (bReader != null) {
                bReader.close();
            }
        } catch (IOException e) {
            System.err.println("Could not close streams");
        }
    }

    private String fileList() {
        StringBuilder ret = new StringBuilder();
        try {
            File fileList = new File("data/server/List.txt");
            Scanner sc = new Scanner(fileList);
            while (sc.hasNextLine()) {
                String musicFiles = sc.nextLine();
                ret.append(musicFiles).append("\n");
            }
            System.out.println("Music list loaded");
            sc.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ret.toString();
    }

    private void getPlaylist(String command) {
        // Implement logic to send the playlist based on the provided command.
        // This logic will depend on how your application handles playlists.
        // Placeholder code for sending a sample playlist:
        if ("PLAYLIST_REQUEST".equals(command)) {
            pWriter.println("PLAYLIST");
            pWriter.println("Song 1 - Artist 1");
            pWriter.println("Song 2 - Artist 2");
            pWriter.println("Song 3 - Artist 3");
            pWriter.flush();
        } else {
            // Handle other playlist-related commands or scenarios here.
            pWriter.println("UNKNOWN_PLAYLIST_COMMAND");
            pWriter.flush();
        }
    }

    @Override
    public void run() {
        try {
            while (isServerRunning) {
                String mes = bReader.readLine();
                System.out.println("Message: " + mes);
                StringTokenizer st = new StringTokenizer(mes);
                String command = st.nextToken().toUpperCase();
                switch (command) {
                    case "BONJOUR": {
                        login();
                        break;
                    }
                    case "PLAYLIST": {
                        getPlaylist(fileList());
                        break;
                    }
                    case "ZEDEMGET": {
                        String fileId = st.nextToken();
                        getMusic(fileId);
                        break;
                    }
                    case "ZEDEMBYE": {
                        logOff();
                        break;
                    }
                    default:
                        pWriter.println("UNKNOWN_COMMAND");
                        pWriter.flush();
                        break;
                }
            }
        } catch (Exception e) {
            System.err.println("Could not run the commands");
        }
    }
    

}
