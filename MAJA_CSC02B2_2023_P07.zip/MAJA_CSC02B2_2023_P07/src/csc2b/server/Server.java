package csc2b.server;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	//Instance variables
	private boolean isrunning = false;
	private ServerSocket serverConnection;
	public Server(int portNumber) {
		try {
			serverConnection = new ServerSocket(portNumber);
			isrunning = true;
			startServer();
		} catch (IOException e) {
			System.out.println("Server could not run!");
		}
	}
	private void startServer() {
		System.out.println("Waiting for client requests");
		while(!isrunning) {
		try {
			Socket socServer = serverConnection.accept();
			System.out.println("Client connected to server");
			ZEDEMHandler handServer = new ZEDEMHandler(socServer);
			Thread thdServer = new Thread(handServer);
			thdServer.start();
		} catch (IOException e) {
			System.out.println("Server could not start!");
		}
		}
	}
	
    public static void main(String[] args) {
    	Server handServer = new Server(2021);
    }
}
